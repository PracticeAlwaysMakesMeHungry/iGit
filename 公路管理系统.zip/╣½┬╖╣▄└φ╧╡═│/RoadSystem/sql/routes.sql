create database routes;
use routes;

create table user(
	username varchar(20),
	password varchar(20),
	role varchar(10)
);

insert into user values('admin', 'admin', 'admin');

create table autoroute(
	Aname varchar(20)
);

create table troncons(
	GodA varchar(20),
	GodT int,
	DuKm float,
	AuKm float,
	SCA int,
	DateDe datetime,
	DateFin datetime,
	Cause text
);

create table villes(
	Libelle varchar(20),
	Numero int,
	CodP int,
	TNom varchar(20)
);

create table troncons_villes(
	GodA varchar(20),
	GodT int,
	TNom varchar(20)
);

create table entreprise(
	SCA int,
	ENom varchar(30),
	CA float,
	duree int
);

create table peage(
	PeageId int,
	PGAuKM float,
	PGDuKm float,
	SCA int
);