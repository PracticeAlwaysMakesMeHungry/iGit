package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Entreprise;
import bean.Troncons;
import db.DBUtil;

public class EntrepriseDao {
	public static void add(Entreprise entreprise) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into entreprise(SCA, ENom, CA, duree) values(?, ?, ?, ?)";

		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setInt(1, entreprise.getSCA());
			pstmt.setString(2, entreprise.getENom());
			pstmt.setFloat(3, entreprise.getCA());
			pstmt.setInt(4, entreprise.getDuree());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	public static void update (Entreprise entreprise) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update entreprise set ENom=?,duree=? where SCA=?";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, entreprise.getENom());
			pstmt.setInt(2, entreprise.getDuree());
			pstmt.setInt(3, entreprise.getSCA());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}		

	}
	
	public static void delete(int SCA) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from entreprise where SCA=?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, SCA);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}	
		
		TronconsDao.cancelEntreprise(SCA);
	}

	public static Entreprise getEntreprise (int SCA, String ENom) {
		Entreprise entreprise = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from entreprise where SCA=? or ENom=?";
		conn = DBUtil.getConn();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, SCA);
			pstmt.setString(2, ENom);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				entreprise = new Entreprise();
				entreprise.setSCA(rs.getInt("SCA"));
				entreprise.setENom(rs.getString("ENom"));
				entreprise.setCA(rs.getFloat("CA"));
				entreprise.setDuree(rs.getInt("duree"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return entreprise;
	}

	public static List<Entreprise> getEntreprises () {
		List<Entreprise> entreprises = new ArrayList<Entreprise>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from entreprise";
		conn = DBUtil.getConn();

		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				Entreprise entreprise = new Entreprise();
				entreprise.setSCA(rs.getInt("SCA"));
				entreprise.setENom(rs.getString("ENom"));
				entreprise.setCA(rs.getFloat("CA"));
				entreprise.setDuree(rs.getInt("duree"));
				entreprises.add(entreprise);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return entreprises;
	}
}
