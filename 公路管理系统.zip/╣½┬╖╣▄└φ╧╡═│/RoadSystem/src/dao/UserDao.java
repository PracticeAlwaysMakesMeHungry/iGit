package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import bean.User;
import db.DBUtil;

public class UserDao {
	public static void add(User user) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into user values(?, ?, ?)";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2,user.getPassword());
			pstmt.setString(3, user.getRole());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
	
	public static String login(String username, String password) {
		String information = "";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String sql = "select * from user where username= '" + username + "'";
		User u = null;
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(!rs.next()) {
				information = "not in";
			} else if(!rs.getString("password").equals(password)) {
				information = "���벻��ȷ";
			}else {
				u = new User();
				u.setUsername(rs.getString("username"));
				u.setPassword(rs.getString("password"));
				u.setRole(rs.getString("role"));
				
				if (u.getRole().equals("admin")) {
					information = "admin";
				} else {
					information = "common";
				}	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return information;
	}
}
