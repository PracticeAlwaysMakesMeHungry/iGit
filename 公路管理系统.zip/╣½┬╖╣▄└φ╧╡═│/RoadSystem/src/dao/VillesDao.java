package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import bean.NodeDto;
import bean.Villes;
import bean.VillesTronconsDto;
import db.DBUtil;

public class VillesDao {
	public static void add(Villes villes) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into villes values(?, ?, ?, ?)";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setString(1, villes.getLibelle());
			pstmt.setInt(2, villes.getNumero());
			pstmt.setInt(3, villes.getCodP());
			pstmt.setString(4, villes.getTNom());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
	
	public static void delete (String GodA) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from troncons_villes where GodA=?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, GodA);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}	
	}
	
	public static void delete (String GodA, int GodT) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from troncons_villes where GodA=? and GodT=?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, GodA);
			pstmt.setInt(2, GodT);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}	
	}
	
	public static void delete (String GodA, int GodT, String TNom) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from troncons_villes where GodA=? and GodT=? and TNom = ?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, GodA);
			pstmt.setInt(2, GodT);
			pstmt.setString(3, TNom);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}	
	}
	
	public static void delete (String libelle, String TNom) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from villes where Libelle =? and TNom=?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, libelle);
			pstmt.setString(2, TNom);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}	
	}
	
	public static Villes getVillesByTNomAndLibelle (String TNom, String Libelle) {
		Villes villes = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from villes where TNom=? and Libelle = ?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, TNom);
			pstmt.setString(2, Libelle);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				villes = new Villes();
				villes.setLibelle(rs.getString("Libelle"));
				villes.setNumero(rs.getInt("Numero"));
				villes.setCodP(rs.getInt("CodP"));
				villes.setTNom(rs.getString("TNom"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return villes;
	}
	
	public static List<String> getTNoms () {
		List<String> toms = new ArrayList<String>();
		List<Villes> villeses = new ArrayList<Villes>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select distinct(TNom) from villes order by TNom";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				toms.add(rs.getString("TNom"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return toms;
	}
	
	public static List<Villes> getVilleses () {
		List<Villes> villeses = new ArrayList<Villes>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from villes order by TNom";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Villes villes = new Villes();
				villes.setLibelle(rs.getString("Libelle"));
				villes.setNumero(rs.getInt("Numero"));
				villes.setCodP(rs.getInt("CodP"));
				villes.setTNom(rs.getString("TNom"));
				villeses.add(villes);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return villeses;
	}
	
	public static List<VillesTronconsDto> getVilleTroncons () {
		List<VillesTronconsDto> villeseTroncons = new ArrayList<VillesTronconsDto>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from troncons_villes order by TNom";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				VillesTronconsDto villesTronconsDto = new VillesTronconsDto();
				villesTronconsDto.setGodA(rs.getString("GodA"));
				villesTronconsDto.setGodT(rs.getInt("GodT"));
				villesTronconsDto.setTNom(rs.getString("TNom"));
				villeseTroncons.add(villesTronconsDto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return villeseTroncons;
	}
	
	public static boolean isTronsVillesExist (String GodA, int GodT, String TNom) {
		boolean isExist = false;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from troncons_villes where GodA = ? and GodT=? and TNom = ?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, GodA);
			pstmt.setInt(2, GodT);
			pstmt.setString(3, TNom);
			
			rs = pstmt.executeQuery();
			if (rs.next()) {
				isExist = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return isExist;
	}
	
	public static void addTroncons(String godA, int GodT, String TNom) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into troncons_villes values(?, ?, ?)";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setString(1, godA);
			pstmt.setInt(2, GodT);
			pstmt.setString(3, TNom);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
	
	public static List<NodeDto> getConnectedVillesByVilleId(String TNom) {
		List<NodeDto> nodes = new ArrayList<NodeDto>();
		String sql = "select b.TNom as beginCity, b.GodA as startGodA ,b.GodT as startGodT,a.TNom as endCity,a.GodA as endGodA, a.GodT as endGodT from troncons_villes a,(select * from troncons_villes where TNom=?) b where a.GodA = b.GodA and a.TNom!=?";
	
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, TNom);
			pstmt.setString(2, TNom);
			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				NodeDto node = new NodeDto();
				node.setBeginCity(rs.getString("beginCity"));
				node.setStartGodA(rs.getString("startGodA"));
				node.setStartGodT(rs.getInt("startGodT"));
				node.setEndCity(rs.getString("endCity"));
				node.setEndGodA(rs.getString("endGodA"));
				node.setEndGodT(rs.getInt("endGodT"));
				nodes.add(node);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return nodes;
	}
}
