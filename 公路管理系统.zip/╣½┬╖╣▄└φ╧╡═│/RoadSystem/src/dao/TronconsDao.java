package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Troncons;
import db.DBUtil;

public class TronconsDao {
	public static void add(Troncons troncons) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into troncons(GodA, GodT, DuKm, AuKm) values(?, ?, ?, ?)";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setString(1, troncons.getGodA());
			pstmt.setInt(2, troncons.getGodT());
			pstmt.setFloat(3, troncons.getDuKm());
			pstmt.setFloat(4, troncons.getAuKm());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
	
	public static void update (Troncons troncons) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update troncons set DuKm=?,AuKm=?,DateDe=?,DateFin=?,cause=? where GodA= ? and GodT=?";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setFloat(1, troncons.getDuKm());
			pstmt.setFloat(2, troncons.getAuKm());
			pstmt.setDate(3, new java.sql.Date(troncons.getDateDe().getTime()));
			pstmt.setDate(4, new java.sql.Date(troncons.getDateFin().getTime()));
			pstmt.setString(5, troncons.getCause());
			pstmt.setString(6, troncons.getGodA());
			pstmt.setInt(7, troncons.getGodT());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
	
	public static void delete(String GodA, int GodT) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from troncons where GodA=? and GodT=?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, GodA);
			pstmt.setInt(2, GodT);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}	
		
		VillesDao.delete(GodA, GodT);
	}
	
	public static void delete(String GodA) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from troncons where GodA=?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, GodA);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}	
	}
	
	public static Troncons getTronconsByGodAAndGodT (String GodA, int GodT) {
		Troncons troncons = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select t.*,e.ENom from troncons t left join entreprise e on t.SCA=e.SCA where t.GodA = ? and t.GodT=?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, GodA);
			pstmt.setInt(2, GodT);
			
			rs = pstmt.executeQuery();
			if (rs.next()) {
				troncons = new Troncons();
				troncons.setGodA(rs.getString("GodA"));
				troncons.setGodT(rs.getInt("GodT"));
				troncons.setDuKm(rs.getFloat("DuKm"));
				troncons.setAuKm(rs.getFloat("AuKm"));
				troncons.setENom(rs.getString("ENom"));
				troncons.setDateDe(rs.getTimestamp("DateDe"));
				troncons.setDateFin(rs.getTimestamp("DateFin"));
				troncons.setCause(rs.getString("Cause"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return troncons;
	}
	
	public static List<Troncons> getTroncons(String GodA) {
		List<Troncons> tronconses = new ArrayList<Troncons>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select t.*,e.ENom from troncons t left join entreprise e on t.SCA=e.SCA where t.GodA = ?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, GodA);
			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Troncons troncons = new Troncons();
				troncons.setGodA(rs.getString("GodA"));
				troncons.setGodT(rs.getInt("GodT"));
				troncons.setDuKm(rs.getFloat("DuKm"));
				troncons.setAuKm(rs.getFloat("AuKm"));
				troncons.setENom(rs.getString("ENom"));
				troncons.setDateDe(rs.getTimestamp("DateDe"));
				troncons.setDateFin(rs.getTimestamp("DateFin"));
				troncons.setCause(rs.getString("Cause"));
				tronconses.add(troncons);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return tronconses;
	}
	
	public static List<Troncons> getTroncons(int SCA) {
		List<Troncons> tronconses = new ArrayList<Troncons>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select t.*,e.ENom from troncons t left join entreprise e on t.SCA=e.SCA where t.SCA = ?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, SCA);
			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Troncons troncons = new Troncons();
				troncons.setGodA(rs.getString("GodA"));
				troncons.setGodT(rs.getInt("GodT"));
				troncons.setDuKm(rs.getFloat("DuKm"));
				troncons.setAuKm(rs.getFloat("AuKm"));
				troncons.setENom(rs.getString("ENom"));
				troncons.setDateDe(rs.getTimestamp("DateDe"));
				troncons.setDateFin(rs.getTimestamp("DateFin"));
				troncons.setCause(rs.getString("Cause"));
				tronconses.add(troncons);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return tronconses;
	}
	
	
	public static List<Troncons> getTronconses () {
		List<Troncons> tronconses = new ArrayList<Troncons>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select t.*,e.ENom from troncons t left join entreprise e on t.SCA=e.SCA order by t.GodA, t.GodT";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Troncons troncons = new Troncons();
				troncons.setGodA(rs.getString("GodA"));
				troncons.setGodT(rs.getInt("GodT"));
				troncons.setDuKm(rs.getFloat("DuKm"));
				troncons.setAuKm(rs.getFloat("AuKm"));
				troncons.setENom(rs.getString("ENom"));
				troncons.setDateDe(rs.getTimestamp("DateDe"));
				troncons.setDateFin(rs.getTimestamp("DateFin"));
				troncons.setCause(rs.getString("Cause"));
				tronconses.add(troncons);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return tronconses;
	}
	

	
	public static int getTronconsByGodAAndGoTAndSCA(String GodA, int GodT) {
		int SCA = 0;
		Troncons troncons = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select SCA from troncons where GodA = ? and GodT=?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, GodA);
			pstmt.setInt(2, GodT);
			
			rs = pstmt.executeQuery();
			if (rs.next()) {
				SCA = rs.getInt("SCA");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return SCA;
	}
	
	public static void cancelEntreprise (String GodA, int GodT) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update troncons set SCA = 0 where GodA= ? and GodT=?";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setString(1, GodA);
			pstmt.setInt(2, GodT);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
	
	public static void cancelEntreprise (int SCA) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update troncons set SCA = 0 where SCA=?";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setInt(1, SCA);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
	
	public static void allocateEntreprise (String GodA, int GodT, int SCA) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update troncons set SCA = ? where GodA= ? and GodT=?";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setInt(1, SCA);
			pstmt.setString(2, GodA);
			pstmt.setInt(3, GodT);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
	
	public static float getDistanceByGodAAndGodT (String GodA, int GodT) {
		float distance = 0.0f;
		String sql = "select AuKm - DuKm as distance, DateDe, DateFin from troncons where GodA = ? and GodT= ?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, GodA);
			pstmt.setInt(2, GodT);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				distance = rs.getFloat("distance");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return distance;
	}
	
	public static float distance (String GodA, int startGodT, int endGodT) {
		float distance = -1f;
		
		if (startGodT > endGodT) {
			for (int i = endGodT; i <= startGodT; i++) {
				distance += getDistanceByGodAAndGodT(GodA, i);
			}
		} else if (startGodT == endGodT) {
			distance = getDistanceByGodAAndGodT(GodA, startGodT);
		} else if (startGodT < endGodT) {
			for (int i = startGodT; i <= endGodT; i++) {
				distance += getDistanceByGodAAndGodT(GodA, i);
			}
		}
		
		return distance;
	}
}
