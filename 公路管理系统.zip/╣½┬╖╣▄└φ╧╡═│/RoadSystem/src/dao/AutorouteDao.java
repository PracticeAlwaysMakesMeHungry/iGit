package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.Autoroute;
import db.DBUtil;

public class AutorouteDao {
	public static void add(Autoroute autoroute) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "insert into autoroute values(?)";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setString(1, autoroute.getAName());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
	
	public static void delete(String AName) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "delete from autoroute where AName=?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, AName);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		TronconsDao.delete(AName);
		VillesDao.delete(AName);
	}
	
	public static Autoroute getAutoroute (String AName) {
		Autoroute autoroute = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from autoroute where AName= ?";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, AName);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				autoroute = new Autoroute();
				autoroute.setAName(rs.getString("AName"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return autoroute;
	}
	
	public static void update (Autoroute autoroute, String AName) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "update autoroute set Aname = ? where Aname= ?";
		
		try {
			conn = DBUtil.getConn();
			pstmt = conn.prepareStatement(sql);	
			pstmt.setString(1, autoroute.getAName());
			pstmt.setString(2, AName);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
	
	public static List<Autoroute> getAutoRoutes () {
		List<Autoroute> autoroutes = new ArrayList<Autoroute>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from autoroute";
		conn = DBUtil.getConn();
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Autoroute autoroute = new Autoroute();
				autoroute.setAName(rs.getString("Aname"));
				autoroutes.add(autoroute);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return autoroutes;
	}
}
