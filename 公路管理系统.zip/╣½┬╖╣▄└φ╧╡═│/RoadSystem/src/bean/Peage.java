package bean;

public class Peage {
	private int PeageId;
	private float PGAuKM;
	private float PGDuKm;
	private int SCA;
	
	public int getPeageId() {
		return PeageId;
	}
	public void setPeageId(int peageId) {
		PeageId = peageId;
	}
	public float getPGAuKM() {
		return PGAuKM;
	}
	public void setPGAuKM(float pGAuKM) {
		PGAuKM = pGAuKM;
	}
	public float getPGDuKm() {
		return PGDuKm;
	}
	public void setPGDuKm(float pGDuKm) {
		PGDuKm = pGDuKm;
	}
	public int getSCA() {
		return SCA;
	}
	public void setSCA(int sCA) {
		SCA = sCA;
	}
}
