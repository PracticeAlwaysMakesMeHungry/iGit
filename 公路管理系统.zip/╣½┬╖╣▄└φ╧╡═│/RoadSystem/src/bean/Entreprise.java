package bean;

public class Entreprise {
	private int SCA;
	private String ENom;
	private float CA;
	private int duree;
	
	public int getSCA() {
		return SCA;
	}
	public void setSCA(int sCA) {
		SCA = sCA;
	}
	public String getENom() {
		return ENom;
	}
	public void setENom(String eNom) {
		ENom = eNom;
	}
	public float getCA() {
		return CA;
	}
	public void setCA(float cA) {
		CA = cA;
	}
	public int getDuree() {
		return duree;
	}
	public void setDuree(int duree) {
		this.duree = duree;
	}
}
