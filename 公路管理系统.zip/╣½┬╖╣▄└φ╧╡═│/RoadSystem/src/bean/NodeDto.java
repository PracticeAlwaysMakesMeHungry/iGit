package bean;

public class NodeDto {
	private String beginCity;
	private String startGodA;
	private int startGodT;
	private String endCity;
	private String endGodA;
	private int endGodT;
	
	public String getBeginCity() {
		return beginCity;
	}
	public void setBeginCity(String beginCity) {
		this.beginCity = beginCity;
	}
	public String getStartGodA() {
		return startGodA;
	}
	public void setStartGodA(String startGodA) {
		this.startGodA = startGodA;
	}
	public int getStartGodT() {
		return startGodT;
	}
	public void setStartGodT(int startGodT) {
		this.startGodT = startGodT;
	}
	public String getEndCity() {
		return endCity;
	}
	public void setEndCity(String endCity) {
		this.endCity = endCity;
	}
	public String getEndGodA() {
		return endGodA;
	}
	public void setEndGodA(String endGodA) {
		this.endGodA = endGodA;
	}
	public int getEndGodT() {
		return endGodT;
	}
	public void setEndGodT(int endGodT) {
		this.endGodT = endGodT;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((beginCity == null) ? 0 : beginCity.hashCode());
		result = prime * result + ((endCity == null) ? 0 : endCity.hashCode());
		result = prime * result + ((endGodA == null) ? 0 : endGodA.hashCode());
		result = prime * result + endGodT;
		result = prime * result
				+ ((startGodA == null) ? 0 : startGodA.hashCode());
		result = prime * result + startGodT;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NodeDto other = (NodeDto) obj;
		if (beginCity == null) {
			if (other.beginCity != null)
				return false;
		} else if (!beginCity.equals(other.beginCity))
			return false;
		if (endCity == null) {
			if (other.endCity != null)
				return false;
		} else if (!endCity.equals(other.endCity))
			return false;
		if (endGodA == null) {
			if (other.endGodA != null)
				return false;
		} else if (!endGodA.equals(other.endGodA))
			return false;
		if (endGodT != other.endGodT)
			return false;
		if (startGodA == null) {
			if (other.startGodA != null)
				return false;
		} else if (!startGodA.equals(other.startGodA))
			return false;
		if (startGodT != other.startGodT)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "NodeDto [beginCity=" + beginCity + ", startGodA=" + startGodA
				+ ", startGodT=" + startGodT + ", endCity=" + endCity
				+ ", endGodA=" + endGodA + ", endGodT=" + endGodT + "]";
	}
}
