package bean;

public class VillesTronconsDto {
	private String GodA;
	private int GodT;
	private String TNom;
	
	public String getGodA() {
		return GodA;
	}
	public void setGodA(String godA) {
		GodA = godA;
	}
	public int getGodT() {
		return GodT;
	}
	public void setGodT(int godT) {
		GodT = godT;
	}
	public String getTNom() {
		return TNom;
	}
	public void setTNom(String tNom) {
		TNom = tNom;
	}
}
