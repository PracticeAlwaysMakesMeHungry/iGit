package bean;

public class Villes {
	private String Libelle;
	private int Numero;
	private int CodP;
	private String TNom;
	
	public String getLibelle() {
		return Libelle;
	}
	public void setLibelle(String libelle) {
		Libelle = libelle;
	}
	public int getNumero() {
		return Numero;
	}
	public void setNumero(int numero) {
		Numero = numero;
	}
	public int getCodP() {
		return CodP;
	}
	public void setCodP(int codP) {
		CodP = codP;
	}
	public String getTNom() {
		return TNom;
	}
	public void setTNom(String tNom) {
		TNom = tNom;
	}
}
