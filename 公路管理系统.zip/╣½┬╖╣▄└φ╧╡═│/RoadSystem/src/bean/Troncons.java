package bean;

import java.util.Date;

public class Troncons {
	private String GodA;
	private int GodT;
	private float DuKm;
	private float AuKm;
	private String ENom;
	private Date DateDe;
	private Date DateFin;
	private String Cause;
	
	public String getGodA() {
		return GodA;
	}
	public void setGodA(String godA) {
		GodA = godA;
	}
	public int getGodT() {
		return GodT;
	}
	public void setGodT(int godT) {
		GodT = godT;
	}
	public float getDuKm() {
		return DuKm;
	}
	public void setDuKm(float duKm) {
		DuKm = duKm;
	}
	public float getAuKm() {
		return AuKm;
	}
	public void setAuKm(float auKm) {
		AuKm = auKm;
	}
	public String getENom() {
		return ENom;
	}
	public void setENom(String eNom) {
		ENom = eNom;
	}
	public Date getDateDe() {
		return DateDe;
	}
	public void setDateDe(Date dateDe) {
		DateDe = dateDe;
	}
	public Date getDateFin() {
		return DateFin;
	}
	public void setDateFin(Date dateFin) {
		DateFin = dateFin;
	}
	public String getCause() {
		return Cause;
	}
	public void setCause(String cause) {
		Cause = cause;
	}
}
