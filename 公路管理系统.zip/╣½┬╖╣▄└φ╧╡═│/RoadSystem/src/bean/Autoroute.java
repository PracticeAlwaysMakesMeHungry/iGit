package bean;

public class Autoroute {
	private String AName;
	
	public String getAName() {
		return AName;
	}
	public void setAName(String aName) {
		AName = aName;
	}
}
