package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import bean.Troncons;
import dao.TronconsDao;

public class UpdateTronconsDialog extends JDialog {
	private JLabel nameLabel = new JLabel("GodA");
	private JLabel autorouteLabel = new JLabel();
	private JLabel godTLabel = new JLabel("GodT");
	private JLabel godTShow = new JLabel();
	private JLabel dukmLabel = new JLabel("DuKm");
	private JTextField dukmTextField = new JTextField();
	private JLabel aukmLabel = new JLabel("AuKm");
	private JTextField aukmTextField = new JTextField();
	private JLabel enomLabel = new JLabel("ENom");
	private JLabel enomShow = new JLabel();
	private JLabel dateDeLabel = new JLabel("DateDe");
	
	private JComboBox<String> yearCombox = new JComboBox<String>();
	private JComboBox<String> monthCombox = new JComboBox<String>();
	private JComboBox<String> dayCombox = new JComboBox<String>();
	
	private JLabel dateFinLabel = new JLabel("DateFin");
	
	private JComboBox<String> FinYearCombox = new JComboBox<String>();
	private JComboBox<String> FinMonthCombox = new JComboBox<String>();
	private JComboBox<String> FinDayCombox = new JComboBox<String>();
	
	private JLabel causeLabel = new JLabel("cause");
	private JTextField causeTextField = new JTextField();
	private JButton okBtn = new JButton("ok");
	private String GodA;
	private int GodT;
	private AdminMainFrame adminMainFrame;
	
	public UpdateTronconsDialog(final String GodA, final int GodT, final AdminMainFrame adminMainFrame) {
		this.GodA = GodA;
		this.GodT = GodT;	
		this.adminMainFrame = adminMainFrame;
		Troncons troncons = TronconsDao.getTronconsByGodAAndGodT(GodA, GodT);
		
		setBounds(200, 200, 360, 300);
		setLayout(null);
		nameLabel.setBounds(60, 10, 140, 20);
		add(nameLabel);

		autorouteLabel.setText(GodA);
		autorouteLabel.setBounds(140, 10, 150, 20);
		add(autorouteLabel);

		godTLabel.setBounds(60, 35, 140, 20);
		add(godTLabel);
		godTShow.setText(GodT + "");
		godTShow.setBounds(140, 35, 150, 20);
		add(godTShow);

		dukmLabel.setBounds(60, 60, 140, 20);
		add(dukmLabel);
		dukmTextField.setText(troncons.getDuKm() + "");
		dukmTextField.setBounds(140, 60, 150, 20);
		add(dukmTextField);

		aukmLabel.setBounds(60, 85, 140, 20);
		add(aukmLabel);
		aukmTextField.setText(troncons.getAuKm() + "");
		aukmTextField.setBounds(140, 85, 150, 20);
		add(aukmTextField);
		
		enomLabel.setBounds(60, 110, 140, 20);
		add(enomLabel);
		
		enomShow.setText(troncons.getENom());
		enomShow.setBounds(140, 110, 150, 20);
		add(enomShow);
		
		dateDeLabel.setBounds(60, 135, 140, 20);
		add(dateDeLabel);
		
		yearCombox.setBounds(140, 135, 70, 20);
		add(yearCombox);
		
		monthCombox.setBounds(220, 135, 50, 20);
		add(monthCombox);
		
		monthCombox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				Object obj = monthCombox.getSelectedItem();

				if (obj != null) { 
					dayCombox.removeAllItems();

					int month = Integer.valueOf(obj.toString());
					int days = 31;
					if (month == 4 || month == 6 || month == 9 || month == 11) {
						days = 30;
					} else if (month == 2) {
						int year = Integer.parseInt(yearCombox.getSelectedItem()
								.toString());

						if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) {
							days = 29;
						} else {
							days = 28;
						}

					}

					for (int j = 0; j < days; j++) {
						dayCombox.addItem("" + (j + 1));
					}
				}
			}
		});
		
		dayCombox.setBounds(280, 135, 50, 20);
		add(dayCombox);
		
		for (int i = 2017; i <= 2100; i++) {
			yearCombox.addItem("" + i);
		}

		for (int i = 0; i < 12; i++) {
			monthCombox.addItem("" + (i + 1));
		}

		for (int j = 0; j < 31; j++) {
			dayCombox.addItem("" + (j + 1));
		}
		
		dateFinLabel.setBounds(60, 160, 140, 20);
		add(dateFinLabel);
		
		FinYearCombox.setBounds(140, 160, 70, 20);
		add(FinYearCombox);
		
		FinMonthCombox.setBounds(220, 160, 50, 20);
		add(FinMonthCombox);
		
		FinMonthCombox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				Object obj = FinMonthCombox.getSelectedItem();

				if (obj != null) { 
					FinDayCombox.removeAllItems();

					int month = Integer.valueOf(obj.toString());
					int days = 31;
					if (month == 4 || month == 6 || month == 9 || month == 11) {
						days = 30;
					} else if (month == 2) {
						int year = Integer.parseInt(FinYearCombox.getSelectedItem()
								.toString());

						if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) {
							days = 29;
						} else {
							days = 28;
						}

					}

					for (int j = 0; j < days; j++) {
						FinDayCombox.addItem("" + (j + 1));
					}
				}
			}
		});
		
		FinDayCombox.setBounds(280, 160, 50, 20);
		add(FinDayCombox);
		
		for (int i = 2017; i <= 2100; i++) {
			FinYearCombox.addItem("" + i);
		}

		for (int i = 0; i < 12; i++) {
			FinMonthCombox.addItem("" + (i + 1));
		}

		for (int j = 0; j < 31; j++) {
			FinDayCombox.addItem("" + (j + 1));
		}
		
		causeLabel.setBounds(60, 185, 140, 20);
		add(causeLabel);
		causeTextField.setText(troncons.getCause());
		causeTextField.setBounds(140, 185, 150, 20);
		add(causeTextField);
		
		okBtn.setBounds(100, 210, 50, 20);
		add(okBtn);
		
		okBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				float duKm = 0;
				float auKm = 0;
				String dateDeStr = yearCombox.getSelectedItem() + "/" + monthCombox.getSelectedItem() + "/" + dayCombox.getSelectedItem();
				String dateFinStr = FinYearCombox.getSelectedItem() + "/" + FinMonthCombox.getSelectedItem() + "/" + FinDayCombox.getSelectedItem();		
				
				String cause = causeTextField.getText();
				
				if (dukmTextField.getText().trim().equals("")) {
					JOptionPane.showMessageDialog(UpdateTronconsDialog.this, "please input DuKm");
					return;
				}

				try {
					duKm = Float.parseFloat(dukmTextField.getText());
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(UpdateTronconsDialog.this, "DuKm should be a Float");
					return;
				}

				if (aukmTextField.getText().trim().equals("")) {
					JOptionPane.showMessageDialog(UpdateTronconsDialog.this, "please input AuKm");
					return;
				}

				try {
					auKm = Float.parseFloat(aukmTextField.getText());
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(UpdateTronconsDialog.this, "AuKm should be a Float");
					return;
				}
				
				if (auKm < duKm) {
					JOptionPane.showMessageDialog(UpdateTronconsDialog.this, "the auKm should bigger than duKm");
					return;
				}
				
				
				if (dateFinStr.compareTo(dateDeStr) < 0) {
					JOptionPane.showMessageDialog(UpdateTronconsDialog.this, "the dateFin is should after dateFe");
					return;
				}
				
				Date dateDe = null;
				Date dateFin = null;
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
				
				try {
					dateDe = sdf.parse(dateDeStr);
					dateFin = sdf.parse(dateFinStr);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				Troncons troncons = new Troncons();
				troncons.setGodA(GodA);
				troncons.setGodT(GodT);
				troncons.setDuKm(duKm);
				troncons.setAuKm(auKm);
				troncons.setDateDe(dateDe);
				troncons.setDateFin(dateFin);
				troncons.setCause(cause);
				
				TronconsDao.update(troncons);
				
				adminMainFrame.getControlPanel().removeAll();
				List<Troncons> tronconses = TronconsDao.getTronconses();
				adminMainFrame.getControlPanel().add(adminMainFrame.getTronconsTable(tronconses));
				adminMainFrame.getControlPanel().updateUI();
				dispose();
			}
		});
		
		setVisible(true);
	}
}
