package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import dao.AutorouteDao;
import dao.TronconsDao;

import bean.Autoroute;
import bean.Troncons;

public class AddTronconsDialog extends JDialog {
	private JLabel nameLabel = new JLabel("GodA");
	private JLabel autorouteLabel = new JLabel();
	private JLabel godTLabel = new JLabel("GodT");
	private JTextField godTTextField = new JTextField();
	private JLabel dukmLabel = new JLabel("DuKm");
	private JTextField dukmTextField = new JTextField();
	private JLabel aukmLabel = new JLabel("AuKm");
	private JTextField aukmTextField = new JTextField();

	private JButton addBtn = new JButton("add");
	private AdminMainFrame adminMainFrame;
	private String AName;

	public AddTronconsDialog(String AName, final AdminMainFrame adminMainFrame) {
		this.AName = AName;
		this.adminMainFrame = adminMainFrame;
		setBounds(200, 200, 360, 180);
		setLayout(null);
		nameLabel.setBounds(60, 10, 140, 20);
		add(nameLabel);

		List<Autoroute> autoroutes = AutorouteDao.getAutoRoutes();

		autorouteLabel.setText(AName);

		autorouteLabel.setBounds(140, 10, 150, 20);
		add(autorouteLabel);

		godTLabel.setBounds(60, 35, 140, 20);
		add(godTLabel);
		godTTextField.setBounds(140, 35, 150, 20);
		add(godTTextField);

		dukmLabel.setBounds(60, 60, 140, 20);
		add(dukmLabel);
		dukmTextField.setBounds(140, 60, 150, 20);
		add(dukmTextField);

		aukmLabel.setBounds(60, 85, 140, 20);
		add(aukmLabel);
		aukmTextField.setBounds(140, 85, 150, 20);
		add(aukmTextField);

		addBtn.setBounds(140, 110, 100, 20);
		add(addBtn);
		addBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String GodA = autorouteLabel.getText();
				int GodT = 0;
				float duKm;
				float auKm;

				if (godTTextField.getText().trim().equals("")) {
					JOptionPane.showMessageDialog(AddTronconsDialog.this, "please input GodT");
					return;
				}

				try {
					GodT = Integer.parseInt(godTTextField.getText());
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(AddTronconsDialog.this, "GodT should be a Integer");
					return;
				}

				if (dukmTextField.getText().trim().equals("")) {
					JOptionPane.showMessageDialog(AddTronconsDialog.this, "please input DuKm");
					return;
				}


				try {
					duKm = Float.parseFloat(dukmTextField.getText());
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(AddTronconsDialog.this, "DuKm should be a Float");
					return;
				}

				if (aukmTextField.getText().trim().equals("")) {
					JOptionPane.showMessageDialog(AddTronconsDialog.this, "please input AuKm");
					return;
				}

				try {
					auKm = Float.parseFloat(aukmTextField.getText());
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(AddTronconsDialog.this, "AuKm should be a Float");
					return;
				}

				if (auKm < duKm) {
					JOptionPane.showMessageDialog(AddTronconsDialog.this, "the auKm should bigger than duKm");
					return;
				}
				
				Troncons temp = TronconsDao.getTronconsByGodAAndGodT(GodA, GodT);

				if (temp != null) {
					JOptionPane.showMessageDialog(AddTronconsDialog.this, "��·���Ѵ���!");
					return;
				}

				Troncons troncons = new Troncons();
				troncons.setGodA(GodA);
				troncons.setGodT(GodT);
				troncons.setDuKm(duKm);
				troncons.setAuKm(auKm);
				TronconsDao.add(troncons);

				adminMainFrame.getControlPanel().removeAll();
				adminMainFrame.getControlPanel().add(adminMainFrame.getAutorouteMngPanel());
				adminMainFrame.getControlPanel().add(adminMainFrame.getAutorouteTable());
				adminMainFrame.getControlPanel().updateUI();

				dispose();
			}
		});
		setVisible(true);
	}
}
