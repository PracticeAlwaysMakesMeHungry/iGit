package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import bean.Autoroute;

import dao.AutorouteDao;

public class UpdateAutoRoutesDialog extends JDialog {
	private JLabel nameLabel = new JLabel("AName");
	private JTextField nameTextField = new JTextField();
	private JButton addBtn = new JButton("ok");
	private String AName;
	private AdminMainFrame adminMainFrame;
	
	public UpdateAutoRoutesDialog(final String AName, final AdminMainFrame adminMainFrame) {
		this.AName = AName;
		this.adminMainFrame = adminMainFrame;
		setBounds(200, 200, 360, 100);
		setLayout(null);
		nameLabel.setBounds(10, 10, 80, 20);
		add(nameLabel);
		nameTextField.setBounds(85, 10, 150, 20);
		add(nameTextField);
		addBtn.setBounds(240, 10, 100, 20);
		add(addBtn);
		
		Autoroute temp = AutorouteDao.getAutoroute(AName);
		nameTextField.setText(temp.getAName());
		
		addBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String name = nameTextField.getText().trim();
				
				if (name.equals(AName)) {
					dispose();
					return;
				}
				
				Autoroute temp = AutorouteDao.getAutoroute(name);
				
				if (name != null && !name.equals("")) {
					if (temp != null) {
						JOptionPane.showMessageDialog(UpdateAutoRoutesDialog.this, "the autoroute is exist");
						return;
					}
					
					Autoroute autoroute = new Autoroute();
					autoroute.setAName(name);
					AutorouteDao.update(autoroute, AName);
					adminMainFrame.getControlPanel().removeAll();
					adminMainFrame.getControlPanel().add(adminMainFrame.getAutorouteMngPanel());
					adminMainFrame.getControlPanel().add(adminMainFrame.getAutorouteTable());
					adminMainFrame.getControlPanel().updateUI();
					dispose();
				}
			}
		});
		setVisible(true);
	}
}
