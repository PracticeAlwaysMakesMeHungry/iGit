package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import util.Path;
import bean.NodeDto;
import dao.TronconsDao;
import dao.VillesDao;

public class CommonMainFrame extends JFrame {
	private static final long serialVersionUID = 1L;

	private JLabel startLabel = new JLabel("start city");
	private JComboBox<String> startComboBox = new JComboBox<String>();
	private JLabel endLabel = new JLabel("end city");
	private JComboBox<String> endComboBox = new JComboBox<String>();
	private JButton queryBtn = new JButton("shortest path");
	private JTextArea infoArea = new JTextArea();
	private JScrollPane scrollPane = new JScrollPane(infoArea);

	public CommonMainFrame() {
		setBounds(100, 100, 800, 600);
		setLayout(null);
		startLabel.setBounds(55, 10, 100, 20);
		add(startLabel);
		startComboBox.setBounds(110, 10, 150, 20);
		add(startComboBox);
		endLabel.setBounds(330, 10, 100, 20);
		add(endLabel);
		endComboBox.setBounds(380, 10, 150, 20);
		add(endComboBox);

		List<String> villes = VillesDao.getTNoms();

		for (String ville : villes) {
			startComboBox.addItem(ville);
			endComboBox.addItem(ville);
		}

		queryBtn.setBounds(540, 10, 120, 20);
		add(queryBtn);

		queryBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String startCity = startComboBox.getSelectedItem().toString();
				String endCity = endComboBox.getSelectedItem().toString();

				if (startCity.equals(endCity)) {
					infoArea.setText("the same city");
					return;
				}

				Path.getPaths(startCity, endCity);
				infoArea.setText("");

				Map<String, NodeDto> routMap = Path.routesMap;

				float min = Float.MAX_VALUE;
				int index = 0;

				for (int i = 0; i < Path.paths.size(); i++) {
					List<String> path = Path.paths.get(i);
					float distance = 0f;

					for (int j = 0; j < path.size() - 1; j++) {
						String start = path.get(j);
						String end = path.get(j + 1);
						NodeDto nodeDto = routMap.get(start + "_" + end);
						distance += TronconsDao.distance(nodeDto.getStartGodA(), nodeDto.getStartGodT(), nodeDto.getEndGodT());
					}

					if (distance < min) {
						min = distance;
						index = i;
					}
				}

				List<String> path = null;
				try {
					path = Path.paths.get(index);
				} catch (Exception e) {
					infoArea.setText("there is no path");
					return;
				}
				for (int j = 0; j < path.size() - 1; j++) {
					System.out.print(path.get(j) + " ");
					String start = path.get(j);
					String end = path.get(j + 1);
					NodeDto nodeDto = routMap.get(start + "_" + end);
					System.out.print(nodeDto.getBeginCity() + "["+ nodeDto.getStartGodA()+nodeDto.getStartGodT() + "] ");
					infoArea.append(nodeDto.getBeginCity() + "["+ nodeDto.getStartGodA()+nodeDto.getStartGodT() + "]->[" + nodeDto.getEndGodA() + nodeDto.getEndGodT() + "]");
					if (j + 1 == path.size() - 1) {
						infoArea.append(nodeDto.getEndCity());
					}
				}
			}
		});
		
		scrollPane.setBounds(10, 35, 760, 500);
		add(scrollPane);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
}
