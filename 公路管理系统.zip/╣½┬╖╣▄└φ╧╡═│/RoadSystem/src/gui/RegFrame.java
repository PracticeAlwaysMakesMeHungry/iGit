package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import bean.User;
import dao.UserDao;

public class RegFrame extends JFrame {

	private static final long serialVersionUID = -5900324006195742591L;
	private JLabel usernameLabel = new JLabel("username"), passwordLabel = new JLabel("password"),
			repasswordLabel = new JLabel("repassword");
	private JTextField userNameTxf = new JTextField();
	private JPasswordField passwordTxf = new JPasswordField();
	private JPasswordField rePasswordTxf = new JPasswordField();

	private JButton regBtn = new JButton("register");

	RegFrame() {
		setBounds(200, 200, 300, 150);
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		usernameLabel.setBounds(10, 10, 70, 20);
		add(usernameLabel);
		userNameTxf.setBounds(80, 10, 80, 20);
		add(userNameTxf);
		passwordLabel.setBounds(10, 40, 70, 20);
		add(passwordLabel);
		passwordTxf.setBounds(80, 40, 80, 20);
		add(passwordTxf);

		repasswordLabel.setBounds(10, 70, 80, 20);
		add(repasswordLabel);

		rePasswordTxf.setBounds(80, 70, 80, 20);
		add(rePasswordTxf);

		regBtn.setBounds(170, 40, 80, 20);
		add(regBtn);

		regBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				action();
			}
		});
		setVisible(true);
	}

	public void action() {
		String password = new String(passwordTxf.getPassword());
		String repassword = new String(rePasswordTxf.getPassword());
		if (!password.equals(repassword)) {
			JOptionPane.showMessageDialog(RegFrame.this, "the repassword is not the same with password");
			passwordTxf.setText("");
			rePasswordTxf.setText("");
			return;
		}

		String username = userNameTxf.getText();
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setRole("common");

		String info = UserDao.login(username, repassword);

		if (!info.equals("not in")) {
			JOptionPane.showMessageDialog(RegFrame.this, "this user is already exist");
			return;
		}

		UserDao.add(user);
		JOptionPane.showMessageDialog(RegFrame.this, "register success��");
		this.dispose();
	}
}
