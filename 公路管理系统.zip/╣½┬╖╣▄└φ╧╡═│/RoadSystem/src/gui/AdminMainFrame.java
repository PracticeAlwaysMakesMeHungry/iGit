package gui;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.AutorouteDao;
import dao.EntrepriseDao;
import dao.TronconsDao;
import dao.VillesDao;

import bean.Autoroute;
import bean.Entreprise;
import bean.Troncons;
import bean.Villes;
import bean.VillesTronconsDto;

public class AdminMainFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JButton autorouteMngBtn = new JButton("autoroutes");
	private JButton tronconsMngBtn = new JButton("troncons");
	private JButton entrepriseMngBtn = new JButton("entreprise");
	private JButton villesMngBtn = new JButton("villes");
	private JButton villes_tronsMngBtn = new JButton("villes_troncons");
	private JPanel controlPanel = new JPanel();

	public AdminMainFrame() {
		setBounds(100, 100, 800, 600);
		setLayout(null);
		autorouteMngBtn.setBounds(10, 10, 150, 20);
		add(autorouteMngBtn);
		tronconsMngBtn.setBounds(160, 10, 150, 20);
		add(tronconsMngBtn);
		entrepriseMngBtn.setBounds(310, 10, 150, 20);
		add(entrepriseMngBtn);
		villesMngBtn.setBounds(460, 10, 150, 20);
		add(villesMngBtn);
		villes_tronsMngBtn.setBounds(610, 10, 150, 20);
		add(villes_tronsMngBtn);
		
		controlPanel.setBounds(10, 35, 770, 550);
		controlPanel.setLayout(null);
		controlPanel.add(getAutorouteMngPanel());
		controlPanel.add(getAutorouteTable());
		add(controlPanel);

		autorouteMngBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				controlPanel.removeAll();
				controlPanel.add(getAutorouteMngPanel());
				controlPanel.add(getAutorouteTable());
				controlPanel.updateUI();
			}
		});

		tronconsMngBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				controlPanel.removeAll();
				//controlPanel.add(getTronconsMngPanel());
				controlPanel.add(getTronconsTable(TronconsDao.getTronconses()));
				controlPanel.updateUI();
			}
		});

		entrepriseMngBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				List<Entreprise> entreprises = EntrepriseDao.getEntreprises();
				controlPanel.removeAll();
				controlPanel.add(getEntrepriseMngPanel());
				controlPanel.add(getEntrepriseTable(entreprises));
				controlPanel.updateUI();
			}
		});

		villesMngBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				controlPanel.removeAll();
				controlPanel.add(getVilleMngPanel());
				controlPanel.add(getVillesTable());
				controlPanel.updateUI();
			}
		});
		
		villes_tronsMngBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				controlPanel.removeAll();
				controlPanel.add(getVillesTronconsTable());
				controlPanel.updateUI();
			}
		});
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	public JPanel getVilleMngPanel () {
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 770, 20);
		panel.setLayout(null);
		JButton addBtn = new JButton("add ville");
		addBtn.setBounds(10, 0, 150, 20);
		addBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				new AddVillesDialog(AdminMainFrame.this);
			}
		});
		panel.add(addBtn);
		return panel;
	}

	public JPanel getEntrepriseMngPanel () {
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 770, 20);
		panel.setLayout(null);
		JButton addBtn = new JButton("add entreprise");
		addBtn.setBounds(10, 0, 150, 20);
		panel.add(addBtn);
		addBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new AddEntrepriseDialog(AdminMainFrame.this);
			}
		});
		return panel;
	}

	public JPanel getAutorouteMngPanel () {
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 770, 20);
		panel.setLayout(null);
		JButton addBtn = new JButton("add autoroutes");
		addBtn.setBounds(10, 0, 150, 20);
		addBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new AddAutoRoutesDialog(AdminMainFrame.this);
			}
		});
		panel.add(addBtn);
		return panel;
	}

	public JScrollPane getVillesTronconsTable () {
		Object[][] rowData = {};
		Object[] columnNames = {"GodA", "GodD", "TNom", "cmd3"};	
		List<VillesTronconsDto> villesTronconsDtos = VillesDao.getVilleTroncons();

		DefaultTableModel defaultTableModel = new DefaultTableModel(rowData, columnNames);
		for (VillesTronconsDto villesTronconsDto : villesTronconsDtos) {
			Object[] auto = {villesTronconsDto.getGodA(), villesTronconsDto.getGodT(), villesTronconsDto.getTNom(), "delete"};
			defaultTableModel.addRow(auto);
		}

		final JTable table = new JTable(defaultTableModel);

		table.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				int col = table.getSelectedColumn();
				String cmd =  table.getValueAt(row, col).toString();
				String GodA = table.getValueAt(row, 0).toString();
				int GodT = Integer.parseInt(table.getValueAt(row, 1).toString());
				String TNom = table.getValueAt(row, 2).toString();

				if (cmd.equals("delete")) {
					VillesDao.delete(GodA, GodT, TNom);
					((DefaultTableModel) table.getModel()).removeRow(row);
				} 
			}    
		});


		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 35, 750, 450);
		return scrollPane;
	}
	
	public JScrollPane getAutorouteTable () {
		Object[][] rowData = {};
		Object[] columnNames = {"AName", "cmd1", "cmd2", "cmd3", "cmd4"};	
		List<Autoroute> autoroutes = AutorouteDao.getAutoRoutes();

		DefaultTableModel defaultTableModel = new DefaultTableModel(rowData, columnNames);
		for (Autoroute autoroute : autoroutes) {
			Object[] auto = {autoroute.getAName(), "add troncons", "look troncons", "delete", "update"};
			defaultTableModel.addRow(auto);
		}

		final JTable table = new JTable(defaultTableModel);

		table.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				int col = table.getSelectedColumn();
				String cmd =  table.getValueAt(row, col).toString();
				String AName = table.getValueAt(row, 0).toString();

				if (cmd.equals("delete")) {
					AutorouteDao.delete(AName);
					((DefaultTableModel) table.getModel()).removeRow(row);
				} else if (cmd.equals("add troncons")) {
					new AddTronconsDialog(AName, AdminMainFrame.this);
				} else if (cmd.equals("look troncons")) {
					List<Troncons> troncons = TronconsDao.getTroncons(AName);
					controlPanel.removeAll();
					controlPanel.add(getTronconsTable(troncons));
					controlPanel.updateUI();
				} else if (cmd.equals("update")) {
					if (!AName.trim().equals("")) {
						new UpdateAutoRoutesDialog(AName, AdminMainFrame.this);
					}
				}
			}    
		});


		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 35, 750, 450);
		return scrollPane;
	}

	public JScrollPane getTronconsTable (List<Troncons> tronconses) {
		Object[][] rowData = {};
		Object[] columnNames = {"GodA", "GodT", "DuKm", "AuKm" ,"ENom" , "DateDe", "DateFin", "cause", "cmd1", "cmd2"};	

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		DefaultTableModel defaultTableModel = new DefaultTableModel(rowData, columnNames);
		for (Troncons troncons : tronconses) {
			String dateDeStr = "";
			String dateFinStr = "";
			if (troncons.getDateDe() != null) {
				dateDeStr = sdf.format(troncons.getDateDe());
			}
			if (troncons.getDateFin() != null) {
				dateFinStr = sdf.format(troncons.getDateFin());
			}
			Object[] auto = {troncons.getGodA(), troncons.getGodT(), troncons.getDuKm(), troncons.getAuKm(), troncons.getENom(), dateDeStr, dateFinStr, troncons.getCause(),  "delete", "update"};
			defaultTableModel.addRow(auto);
		}

		final JTable table = new JTable(defaultTableModel);

		table.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				int col = table.getSelectedColumn();
				String cmd =  table.getValueAt(row, col).toString();
				String GodA = table.getValueAt(row, 0).toString();
				int GodT = Integer.parseInt(table.getValueAt(row, 1).toString());

				if (cmd.equals("delete")) {
					TronconsDao.delete(GodA, GodT);
					((DefaultTableModel) table.getModel()).removeRow(row);
				} else if (cmd.equals("update")) {
					new UpdateTronconsDialog(GodA, GodT, AdminMainFrame.this);
				}
			}    
		});
	
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 35, 750, 450);
		return scrollPane;
	}
	
	public JScrollPane getEntrepriseTronconsTable (List<Troncons> tronconses) {
		Object[][] rowData = {};
		Object[] columnNames = {"GodA", "GodT", "DuKm", "AuKm" ,"ENom" , "DateDe", "DateFin", "cause", "cmd1"};	

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		DefaultTableModel defaultTableModel = new DefaultTableModel(rowData, columnNames);
		for (Troncons troncons : tronconses) {
			String dateDeStr = "";
			String dateFinStr = "";
			if (troncons.getDateDe() != null) {
				dateDeStr = sdf.format(troncons.getDateDe());
			}
			if (troncons.getDateFin() != null) {
				dateFinStr = sdf.format(troncons.getDateFin());
			}
			Object[] auto = {troncons.getGodA(), troncons.getGodT(), troncons.getDuKm(), troncons.getAuKm(), troncons.getENom(), dateDeStr, dateFinStr, troncons.getCause(),  "delete"};
			defaultTableModel.addRow(auto);
		}

		final JTable table = new JTable(defaultTableModel);

		table.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				int col = table.getSelectedColumn();
				String cmd =  table.getValueAt(row, col).toString();
				String GodA = table.getValueAt(row, 0).toString();
				int GodT = Integer.parseInt(table.getValueAt(row, 1).toString());

				if (cmd.equals("delete")) {
					TronconsDao.cancelEntreprise(GodA, GodT);
					((DefaultTableModel) table.getModel()).removeRow(row);
				}
			}    
		});
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 35, 750, 450);
		return scrollPane;
	}
	
	public JScrollPane getEntrepriseTable (List<Entreprise> entreprises) {
		Object[][] rowData = {};
		Object[] columnNames = {"SCA", "ENom", "CA", "duree", "cmd1", "cmd2", "cmd3", "cmd4"};	

		DefaultTableModel defaultTableModel = new DefaultTableModel(rowData, columnNames);
		for (Entreprise entreprise : entreprises) {
			Object[] auto = {entreprise.getSCA(), entreprise.getENom(), entreprise.getCA(), entreprise.getDuree(), "delete", "update", "add troncons", "look troncons"};
			defaultTableModel.addRow(auto);
		}

		final JTable table = new JTable(defaultTableModel);

		table.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				int col = table.getSelectedColumn();
				String cmd =  table.getValueAt(row, col).toString();
				int SCA = Integer.parseInt(table.getValueAt(row, 0).toString());
				String ENom = table.getValueAt(row, 1).toString();

				if (cmd.equals("delete")) {
					EntrepriseDao.delete(SCA);
					((DefaultTableModel) table.getModel()).removeRow(row);
				} else if (cmd.equals("update")) {
					new UpdateEntrepriseDialog(AdminMainFrame.this, SCA, ENom);
				} else if (cmd.equals("add troncons")) {
					new ConfigTronconsEntrepriseDialog(SCA);
				} else if (cmd.equals("look troncons")) {
					List<Troncons> troncons = TronconsDao.getTroncons(SCA);
					controlPanel.removeAll();
					controlPanel.add(getEntrepriseTronconsTable(troncons));
					controlPanel.updateUI();
				}
			}    
		});
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 35, 750, 450);
		return scrollPane;
	}

	public JScrollPane getVillesTable () {
		Object[][] rowData = {};
		Object[] columnNames = {"Libelle", "Numero", "CodP", "TNom", "cmd1", "cmd2"};	
		List<Villes> villeses = VillesDao.getVilleses();

		DefaultTableModel defaultTableModel = new DefaultTableModel(rowData, columnNames);
		for (Villes villes : villeses) {
			Object[] auto = {villes.getLibelle(), villes.getNumero(), villes.getCodP(), villes.getTNom(), "delete", "add troncons"};
			defaultTableModel.addRow(auto);
		}

		final JTable table = new JTable(defaultTableModel);

		table.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				int col = table.getSelectedColumn();
				String cmd =  table.getValueAt(row, col).toString();
				String TNom = table.getValueAt(row, 3).toString();
				String Libelle = table.getValueAt(row, 0).toString();

				if (cmd.equals("delete")) {
					VillesDao.delete(Libelle, TNom);
					((DefaultTableModel) table.getModel()).removeRow(row);
				} else if (cmd.equals("add troncons")) {
					new ConfigTronconsVillesDialog(TNom, Libelle);
				} else if (cmd.equals("look troncons")) {
					
				}
			}    
		});
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 35, 750, 450);
		return scrollPane;
	}

	public JPanel getControlPanel() {
		return controlPanel;
	}
}
