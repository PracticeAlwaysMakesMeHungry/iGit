package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import dao.UserDao;


public class LoginFrame extends JFrame {

	private static final long serialVersionUID = -5900324006195742591L;
	private JLabel usernameLabel = new JLabel("username"), passwordLabel = new JLabel("password");
	private JTextField userNameTxf = new JTextField();
	private JPasswordField passwordTxf = new JPasswordField();
	private JPasswordField rePasswordTxf = new JPasswordField();
	
	private JButton loginBtn = new JButton("login");
	private JButton regBtn = new JButton("register");
	
	LoginFrame() {
		setBounds(200, 200, 300, 130);
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		usernameLabel.setBounds(20, 10, 70, 20);
		add(usernameLabel);
		userNameTxf.setBounds(80, 10, 80, 20);
		add(userNameTxf);
		passwordLabel.setBounds(20, 40, 70, 20);
		add(passwordLabel);
		passwordTxf.setBounds(80, 40, 80, 20);
		add(passwordTxf);
		
		loginBtn.setBounds(170, 10, 80, 20);
		add(loginBtn);
		regBtn.setBounds(170, 40, 80, 20);
		add(regBtn);
		
		loginBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				actionPeform();
			}
		});
		
		regBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new RegFrame();
			}
		});
		setVisible(true);
	}
	
	public void actionPeform() {
		String username = userNameTxf.getText();
		String password = new String(passwordTxf.getPassword());
		
		String info = UserDao.login(username, password);
		
		if (info.equals("admin")) {
			new AdminMainFrame();
			this.dispose();
		} else if (info.equals("common")) {
			new CommonMainFrame();
			this.dispose();
		} else {
			JOptionPane.showMessageDialog(LoginFrame.this, "username or password is invalid");
			return;
		}
	}
	
	public static void main(String[] args) {
		new LoginFrame().setVisible(true);
	}
}
