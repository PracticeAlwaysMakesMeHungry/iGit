package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import bean.Entreprise;
import dao.EntrepriseDao;

public class UpdateEntrepriseDialog extends JDialog {
	private JLabel SCALabel = new JLabel("SCA");
	private JLabel sCAShowLabel = new JLabel();
	private JLabel ENomLabel = new JLabel("ENom");
	private JTextField ENomField = new JTextField();
	private JLabel dureeLabel = new JLabel("duree");
	private JTextField dureeTextField = new JTextField();
	private JButton addBtn = new JButton("ok");
	private AdminMainFrame adminMainFrame;
	private int SCA;
	private String ENom;
	
	public UpdateEntrepriseDialog(final AdminMainFrame adminMainFrame, final int SCA, String ENom) {
		this.adminMainFrame = adminMainFrame;
		this.SCA = SCA;
		this.ENom = ENom;
		Entreprise entreprise = EntrepriseDao.getEntreprise(SCA, ENom);
		
		setBounds(200, 200, 300, 150);
		setLayout(null);
		SCALabel.setBounds(10, 10, 50, 20);
		add(SCALabel);
		sCAShowLabel.setText(SCA + "");
		sCAShowLabel.setBounds(60, 10, 150, 20);
		add(sCAShowLabel);
		ENomLabel.setBounds(10, 35, 50, 20);
		add(ENomLabel);
		ENomField.setBounds(60, 35, 150, 20);
		add(ENomField);
		dureeLabel.setBounds(10, 60, 50, 20);
		add(dureeLabel);
		dureeTextField.setBounds(60, 60, 150, 20);
		add(dureeTextField);
		addBtn.setBounds(100, 85, 80, 20);
		add(addBtn);
		
		ENomField.setText(entreprise.getENom());
		dureeTextField.setText(entreprise.getDuree() + "");
		
		addBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String ENom = ENomField.getText();
				int duree;
				
				
				if (ENom.trim().equals("")) {
					JOptionPane.showMessageDialog(UpdateEntrepriseDialog.this, "the Enom of a entreprise should not empty");
					return;
				}
				
				try {
					duree = Integer.parseInt(dureeTextField.getText().trim());
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(UpdateEntrepriseDialog.this, "duree should be a Integer");
					return;
				}
				
				Entreprise entreprise = new Entreprise();
				entreprise.setSCA(SCA);
				entreprise.setENom(ENom);
				entreprise.setDuree(duree);
				
				EntrepriseDao.update(entreprise);
				
				List<Entreprise> entreprises = EntrepriseDao.getEntreprises();
				adminMainFrame.getControlPanel().removeAll();
				adminMainFrame.getControlPanel().add(adminMainFrame.getEntrepriseMngPanel());
				adminMainFrame.getControlPanel().add(adminMainFrame.getEntrepriseTable(entreprises));
				adminMainFrame.getControlPanel().updateUI();
				
				dispose();
			}
		});
		setVisible(true);
	}
}
