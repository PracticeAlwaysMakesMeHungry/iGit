package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import dao.AutorouteDao;
import dao.TronconsDao;
import dao.VillesDao;

import bean.Autoroute;
import bean.Troncons;
import bean.Villes;

public class ConfigTronconsVillesDialog extends JDialog {
	private JLabel autoRouteLabel = new JLabel("GodA");
	private JComboBox<String> autoRouteComboBox = new JComboBox<String>();
	private JLabel tronconsLabel = new JLabel("GodD");
	private JComboBox<String> tronconsComboBox = new JComboBox<String>();
	private JLabel villeLabel = new JLabel("TNom");
	private JLabel cityNameLabel = new JLabel();
	private JLabel libeLLeLabel = new JLabel("Libelle");
	private JLabel LibeLLEShowLabel = new JLabel();
	private JButton addBtn = new JButton("add");
	private String TNom;
	private String Libelle;

	public ConfigTronconsVillesDialog(final String TNom, final String Libelle) {
		this.TNom = TNom;
		this.Libelle = Libelle;
		setBounds(200, 200, 360, 180);
		setLayout(null);
		List<Autoroute> autoroutes = AutorouteDao.getAutoRoutes();

		for (Autoroute autoroute : autoroutes) {
			autoRouteComboBox.addItem(autoroute.getAName());
		}

		autoRouteComboBox.addItemListener(new ItemListener() {
			int index = 0;

			@Override
			public void itemStateChanged(ItemEvent arg0) {

				Object obj = autoRouteComboBox.getSelectedItem();

				if (obj != null) { 
					tronconsComboBox.removeAllItems();
					List<Troncons> troncons = TronconsDao.getTroncons(autoRouteComboBox.getSelectedItem().toString().trim());
		
					for (Troncons troncon : troncons) {
						tronconsComboBox.addItem(troncon.getGodT() + "");
					}
				}

			}
		});

		autoRouteLabel.setBounds(60, 10, 150, 20);
		add(autoRouteLabel);
		autoRouteComboBox.setBounds(160, 10, 150, 20);
		add(autoRouteComboBox);

		tronconsLabel.setBounds(60, 35, 150, 20);
		add(tronconsLabel);

		List<Troncons> troncons = TronconsDao.getTroncons(autoRouteComboBox.getSelectedItem().toString().trim());

		for (Troncons troncon : troncons) {
			tronconsComboBox.addItem(troncon.getGodT() + "");
		}

		tronconsComboBox.setBounds(160, 35, 150, 20);
		add(tronconsComboBox);
		
		villeLabel.setBounds(60, 60, 150, 20);
		add(villeLabel);
		
		List<Villes> villes = VillesDao.getVilleses();
		
		cityNameLabel.setText(TNom);
		
		cityNameLabel.setBounds(160, 60, 150, 20);
		add(cityNameLabel);
		
		libeLLeLabel.setBounds(60, 85, 60, 20);
		add(libeLLeLabel);
		
		LibeLLEShowLabel.setText(Libelle);
		LibeLLEShowLabel.setBounds(160, 85, 160, 20);
		add(LibeLLEShowLabel);
		
		addBtn.setBounds(120, 110, 150, 20);
		addBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!tronconsComboBox.getSelectedItem().toString().trim().equals("")) {
					String godA = autoRouteComboBox.getSelectedItem().toString().trim();
					int GodT = Integer.parseInt(tronconsComboBox.getSelectedItem().toString()); 
					
					if (VillesDao.isTronsVillesExist(godA, GodT, TNom)) {
						JOptionPane.showMessageDialog(ConfigTronconsVillesDialog.this, "the infomation is exist!");
						return;
					}
					
					VillesDao.addTroncons(godA, GodT, TNom);
					dispose();
				}
			}
		});
		add(addBtn);

		setVisible(true);
	}
}
