package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import bean.Entreprise;
import dao.EntrepriseDao;

public class AddEntrepriseDialog extends JDialog {
	private JLabel SCALabel = new JLabel("SCA");
	private JTextField sCATextField = new JTextField();
	private JLabel ENomLabel = new JLabel("ENom");
	private JTextField ENomField = new JTextField();
	private JLabel dureeLabel = new JLabel("duree");
	private JTextField dureeTextField = new JTextField();
	private JButton addBtn = new JButton("add");
	private AdminMainFrame adminMainFrame;
	
	public AddEntrepriseDialog(final AdminMainFrame adminMainFrame) {
		this.adminMainFrame = adminMainFrame;
		setBounds(200, 200, 300, 150);
		setLayout(null);
		SCALabel.setBounds(10, 10, 50, 20);
		add(SCALabel);
		sCATextField.setBounds(60, 10, 150, 20);
		add(sCATextField);
		ENomLabel.setBounds(10, 35, 50, 20);
		add(ENomLabel);
		ENomField.setBounds(60, 35, 150, 20);
		add(ENomField);
		dureeLabel.setBounds(10, 60, 50, 20);
		add(dureeLabel);
		dureeTextField.setBounds(60, 60, 150, 20);
		add(dureeTextField);
		addBtn.setBounds(100, 85, 80, 20);
		add(addBtn);
		
		addBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				int SCA;
				String ENom = ENomField.getText();
				int duree;
				
				try {
					SCA = Integer.parseInt(sCATextField.getText().trim());
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(AddEntrepriseDialog.this, "SCA should be a Integer");
					return;
				}
				
				if (ENom.trim().equals("")) {
					JOptionPane.showMessageDialog(AddEntrepriseDialog.this, "the Enom of a entreprise should not empty");
					return;
				}
				
				try {
					duree = Integer.parseInt(dureeTextField.getText().trim());
				} catch (NumberFormatException e) {
					JOptionPane.showMessageDialog(AddEntrepriseDialog.this, "duree should be a Integer");
					return;
				}
				
				Entreprise temp = EntrepriseDao.getEntreprise(SCA, ENom);
				
				if (temp != null) {
					JOptionPane.showMessageDialog(AddEntrepriseDialog.this, "the information is already exist");
					return;
				}
				
				Entreprise entreprise = new Entreprise();
				entreprise.setSCA(SCA);
				entreprise.setENom(ENom);
				entreprise.setDuree(duree);
				
				EntrepriseDao.add(entreprise);
				
				List<Entreprise> entreprises = EntrepriseDao.getEntreprises();
				adminMainFrame.getControlPanel().removeAll();
				adminMainFrame.getControlPanel().add(adminMainFrame.getEntrepriseMngPanel());
				adminMainFrame.getControlPanel().add(adminMainFrame.getEntrepriseTable(entreprises));
				adminMainFrame.getControlPanel().updateUI();
				
				dispose();
			}
		});
		setVisible(true);
	}
}
