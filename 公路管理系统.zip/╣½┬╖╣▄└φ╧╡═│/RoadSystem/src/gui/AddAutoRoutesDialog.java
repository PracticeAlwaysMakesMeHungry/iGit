package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import bean.Autoroute;

import dao.AutorouteDao;

public class AddAutoRoutesDialog extends JDialog {
	private JLabel nameLabel = new JLabel("AName");
	private JTextField nameTextField = new JTextField();
	private JButton addBtn = new JButton("add");
	private AdminMainFrame adminMainFrame;

	public AddAutoRoutesDialog(final AdminMainFrame adminMainFrame) {
		this.adminMainFrame = adminMainFrame;
		setBounds(200, 200, 360, 100);
		setLayout(null);
		nameLabel.setBounds(10, 10, 80, 20);
		add(nameLabel);
		nameTextField.setBounds(85, 10, 150, 20);
		add(nameTextField);
		addBtn.setBounds(240, 10, 100, 20);
		add(addBtn);
		addBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String name = nameTextField.getText().trim();
				if (name == null || name.equals("")) {
					JOptionPane.showMessageDialog(AddAutoRoutesDialog.this, "please input AName");
					return;
				}

				Autoroute temp = AutorouteDao.getAutoroute(name);

				if (temp != null) {
					JOptionPane.showMessageDialog(AddAutoRoutesDialog.this, "the autoroute is exist");
					return;
				}

				Autoroute autoroute = new Autoroute();
				autoroute.setAName(name);
				AutorouteDao.add(autoroute);
				adminMainFrame.getControlPanel().removeAll();
				adminMainFrame.getControlPanel().add(adminMainFrame.getAutorouteMngPanel());
				adminMainFrame.getControlPanel().add(adminMainFrame.getAutorouteTable());
				adminMainFrame.getControlPanel().updateUI();
				dispose();
			}
		});
		setVisible(true);
	}
}
