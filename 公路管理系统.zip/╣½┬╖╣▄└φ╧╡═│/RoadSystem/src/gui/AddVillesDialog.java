package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import dao.VillesDao;
import bean.Villes;

public class AddVillesDialog extends JDialog {
	private JLabel LibelLabel = new JLabel("Libelle");
	private JTextField libelTextField = new JTextField();
	private JLabel NumeroLabel = new JLabel("Numero");
	private JTextField numeroTextField = new JTextField();
	private JLabel CodPLabel = new JLabel("CodP");
	private JTextField codPTextField = new JTextField();
	private JLabel TNomLabel = new JLabel("TNom");
	private JTextField TNomTextField = new JTextField();
	private JButton addBtn = new JButton("add");
	private AdminMainFrame adminMainFrame;
	
	public AddVillesDialog(final AdminMainFrame adminMainFrame) {
		this.adminMainFrame = adminMainFrame;
		setBounds(200, 200, 360, 180);
		setLayout(null);
		LibelLabel.setBounds(40, 10, 70, 20);
		add(LibelLabel);
		libelTextField.setBounds(110, 10, 150, 20);
		add(libelTextField);
		NumeroLabel.setBounds(40, 35, 70, 20);
		add(NumeroLabel);
		numeroTextField.setBounds(110, 35, 150, 20);
		add(numeroTextField);
		CodPLabel.setBounds(40, 60, 70, 20);
		add(CodPLabel);
		codPTextField.setBounds(110, 60, 150, 20);
		add(codPTextField);
		TNomLabel.setBounds(40, 85, 70, 20);
		add(TNomLabel);
		TNomTextField.setBounds(110, 85, 150, 20);
		add(TNomTextField);
		addBtn.setBounds(140, 110, 100, 20);
		add(addBtn);
		addBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String Libelle = libelTextField.getText();
				int Numero = Integer.parseInt(numeroTextField.getText());
				int CodP = Integer.parseInt(codPTextField.getText());
				String Tnom = TNomTextField.getText();
				
				Villes temp = VillesDao.getVillesByTNomAndLibelle(Tnom, Libelle);
				
				if (temp != null) {
					JOptionPane.showMessageDialog(AddVillesDialog.this, "the information is already exist!");
					return;
				}
				
				Villes villes = new Villes();
				villes.setLibelle(Libelle);
				villes.setNumero(Numero);
				villes.setCodP(CodP);
				villes.setTNom(Tnom);
				VillesDao.add(villes);
				
				adminMainFrame.getControlPanel().removeAll();
				adminMainFrame.getControlPanel().add(adminMainFrame.getVilleMngPanel());
				adminMainFrame.getControlPanel().add(adminMainFrame.getVillesTable());
				adminMainFrame.getControlPanel().updateUI();
				dispose();
			}
		});
		setVisible(true);
	}
}
