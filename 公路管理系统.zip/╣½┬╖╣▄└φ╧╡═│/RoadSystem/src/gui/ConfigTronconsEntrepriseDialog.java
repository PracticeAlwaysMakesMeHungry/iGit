package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import bean.Autoroute;
import bean.Troncons;
import dao.AutorouteDao;
import dao.TronconsDao;

public class ConfigTronconsEntrepriseDialog extends JDialog {
	private JLabel ENomLabel = new JLabel("entreprise");
	private JLabel eNomTextField = new JLabel();
	private JLabel autoRouteLabel = new JLabel("GodA");
	private JComboBox<String> autoRouteComboBox = new JComboBox<String>();
	private JLabel tronconsLabel = new JLabel("GodT");
	private JComboBox<String> tronconsComboBox = new JComboBox<String>();
	private JButton addBtn = new JButton("ok");
	private int SCA;
	
	public ConfigTronconsEntrepriseDialog(final int SCA) {
		this.SCA = SCA;
		List<Autoroute> autoroutes = AutorouteDao.getAutoRoutes();

		setBounds(200, 200, 300, 180);
		setLayout(null);
		
		eNomTextField.setText(SCA + "");
		for (Autoroute autoroute : autoroutes) {
			autoRouteComboBox.addItem(autoroute.getAName());
		}

		autoRouteComboBox.addItemListener(new ItemListener() {
			int index = 0;

			@Override
			public void itemStateChanged(ItemEvent arg0) {

				Object obj = autoRouteComboBox.getSelectedItem();

				if (obj != null) { 
					tronconsComboBox.removeAllItems();
					List<Troncons> troncons = TronconsDao.getTroncons(autoRouteComboBox.getSelectedItem().toString().trim());
		
					for (Troncons troncon : troncons) {
						tronconsComboBox.addItem(troncon.getGodT() + "");
					}
				}

			}
		});
		
		List<Troncons> troncons = TronconsDao.getTroncons(autoRouteComboBox.getSelectedItem().toString().trim());

		for (Troncons troncon : troncons) {
			tronconsComboBox.addItem(troncon.getGodT() + "");
		}
		
		autoRouteLabel.setBounds(30, 10, 50, 20);
		add(autoRouteLabel);
		autoRouteComboBox.setBounds(110, 10, 150, 20);
		add(autoRouteComboBox);

		tronconsLabel.setBounds(30, 35, 50, 20);
		add(tronconsLabel);
		
		tronconsComboBox.setBounds(110, 35, 150, 20);
		add(tronconsComboBox);
		
		ENomLabel.setBounds(10, 60, 100, 20);
		add(ENomLabel);
		eNomTextField.setBounds(110, 60, 150,20);
		add(eNomTextField);
		
		addBtn.setBounds(100, 85, 50, 20);
		add(addBtn);
		
		addBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String GodA = autoRouteComboBox.getSelectedItem().toString();
				int GodT = Integer.parseInt(tronconsComboBox.getSelectedItem().toString());
				int temp =TronconsDao.getTronconsByGodAAndGoTAndSCA(GodA, GodT);
				
				System.out.println(temp);
				if (temp != 0) {
					JOptionPane.showMessageDialog(ConfigTronconsEntrepriseDialog.this, "the troncons is manager by a entreprise");
					return;
				}
				
				TronconsDao.allocateEntreprise(GodA, GodT, SCA);
				dispose();
			}
		});
		
		setVisible(true);
	}
}
