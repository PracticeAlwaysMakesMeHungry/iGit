package MD5;

public class main {
    public static void main(String[] args) throws Exception { 
    	    MD5 md5 = new MD5();
    		String message = "12345";
    		String passwordMD5 = null;
    		System.out.println("message:"+message+"\n"); 
    		passwordMD5 = md5.getMD5(message); 
    		System.out.println("AfterMD5:"+passwordMD5+"\n"); 
    		
    }  
}
